# MindMate AI

**AI-Powered Mental Wellness Tracker for Competitive Exam Students**

A beautiful, production-grade React application built to support students preparing for NEET, JEE, UPSC, GATE and other high-pressure exams. Helps track mood, journal emotions, detect burnout early, receive AI coaching from Gemini and build sustainable habits.

![MindMate AI](https://picsum.photos/id/1015/1200/630)

## ✨ Features

- **Daily AI Mood Check-ins** with stress, energy, sleep and study hour tracking
- **Emotional Journal** with real-time Gemini-powered analysis (emotion, triggers, risk, suggestions)
- **Burnout Prediction Engine** using trend analysis
- **AI Wellness Coach Chatbot** (motivation, breathing exercises, reframing)
- **Rich Analytics Dashboard** with Recharts visualizations (mood trends, distribution, sleep correlation)
- **Personalized Wellness Plans** generated dynamically
- **Gamification**: XP system, streak counter, unlockable badges
- **Emergency Detection** with helpline prompts for critical keywords
- **Glassmorphism Dark UI** with smooth Framer Motion animations
- **Local persistence** (localStorage) simulating Firestore

**Note**: This is a fully functional frontend demonstration. In a real production version, this would be connected to Firebase Auth + Firestore + the actual Google Gemini API.

## Tech Stack

- **Frontend**: React 19 + TypeScript + Vite + Tailwind CSS v4
- **UI/Animations**: Framer Motion, Lucide Icons
- **Charts**: Recharts
- **AI Simulation**: Custom GeminiService with structured mock outputs (ready to be swapped for real Gemini API)
- **State**: React hooks + localStorage

## Quick Start

```bash
# Install dependencies
npm install

# Start dev server
npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

## Project Structure

```
├── src/
│   ├── App.tsx                 # Main application with all tabs
│   ├── types/index.ts          # TypeScript interfaces
│   ├── lib/gemini.ts           # Mock Gemini AI service
│   ├── utils/cn.ts             # Class name utility
│   ├── index.css               # Tailwind imports
│   └── main.tsx
├── public/
├── index.html
├── tailwind.config.ts (integrated in v4)
├── vite.config.ts
├── package.json
└── README.md
```

## Database Schema (Firestore - for production)

```ts
users (collection)
  └─ {userId}
       ├── moodEntries (subcollection)
       ├── journals (subcollection)
       ├── wellnessPlans
       ├── insights
       └── achievements

// Example MoodEntry
{
  timestamp: Timestamp,
  mood: "anxious",
  stressLevel: 8,
  energyLevel: 4,
  sleepHours: 5.5,
  studyHours: 9,
  note: "..."
}
```

## Gemini Integration (Production)

The `GeminiService` is structured to be easily replaced with the real Google Gemini API using the `@google/generative-ai` SDK.

Example real implementation would use:

- `Gemini 2.5 Pro` with function calling for structured JSON output
- Safety settings to prevent harmful content
- Structured output for mood analysis, burnout risk, etc.

See `src/lib/gemini.ts` for the mock functions that mirror the real expected contract.

## Key UX Highlights

- Mobile-first responsive design
- Glassmorphic dark aesthetic with primary accent `#00DC82`
- Instant feedback with XP gain animations and toasts
- Safety guardrails and crisis detection
- Beautiful data visualizations

## Future / Bonus Features Implemented in Demo

- Voice journal entry simulation possible via browser SpeechRecognition API
- PWA ready (add manifest)
- Exportable PDF reports (can be added with jsPDF)
- AI Mood heatmap (extendable)

## Deployment

- **Vercel**: `vercel --prod`
- **Firebase Hosting**: `npm run build && firebase deploy`

Built with ❤️ for students facing immense academic pressure.

**Disclaimer**: This tool is for educational and general wellness tracking only. It is not a replacement for professional mental healthcare. In case of severe distress please contact a licensed counselor or use the helplines displayed in the application.

---

**Made as a complete demonstration for Google Cloud + Gemini + Student Wellness use-case.**
