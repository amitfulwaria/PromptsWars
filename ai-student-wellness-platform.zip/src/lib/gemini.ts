import { MoodEntry, JournalEntry } from '../types';

export class GeminiService {
  static async analyzeMood(entry: Omit<MoodEntry, 'id' | 'timestamp'>): Promise<any> {
    // Mock Gemini analysis
    const moodScores = {
      happy: { risk: 'low', score: 85 },
      calm: { risk: 'low', score: 78 },
      neutral: { risk: 'medium', score: 60 },
      anxious: { risk: 'high', score: 35 },
      sad: { risk: 'high', score: 25 },
      'burned-out': { risk: 'high', score: 15 },
    };

    const risk = moodScores[entry.mood].risk;
    const resilience = moodScores[entry.mood].score;

    return {
      burnoutRisk: risk,
      resilienceScore: resilience,
      insight: entry.mood === 'burned-out' 
        ? "High burnout detected. Consider taking a full rest day and speaking with a counselor."
        : "Consistent energy levels noted. Your body is adapting well to the study load.",
      triggers: entry.stressLevel > 7 
        ? ["Exam pressure", "Long study hours"] 
        : ["Minor time management"],
      recommendation: "Try the 4-7-8 breathing technique for 5 minutes before studying."
    };
  }

  static async analyzeJournal(content: string): Promise<JournalEntry['analysis']> {
    const lowerContent = content.toLowerCase();
    
    let primaryEmotion = 'Anxious';
    let stressSeverity = 6;
    let burnoutRisk: 'low' | 'medium' | 'high' = 'medium';
    let confidenceScore = 72;
    let triggers: string[] = [];

    if (lowerContent.includes('worried') || lowerContent.includes('anxious') || lowerContent.includes('exam')) {
      primaryEmotion = 'Anxious';
      stressSeverity = 8;
      burnoutRisk = 'high';
      triggers = ['Exam pressure', 'Self-comparison'];
    } else if (lowerContent.includes('tired') || lowerContent.includes('exhausted') || lowerContent.includes('burnout')) {
      primaryEmotion = 'Exhausted';
      stressSeverity = 9;
      burnoutRisk = 'high';
      triggers = ['Sleep deficit', 'Overstudying'];
    } else if (lowerContent.includes('happy') || lowerContent.includes('good') || lowerContent.includes('progress')) {
      primaryEmotion = 'Hopeful';
      stressSeverity = 3;
      burnoutRisk = 'low';
      confidenceScore = 88;
    }

    // Check for emergency keywords
    const emergencyKeywords = ['suicide', 'kill myself', 'self harm', 'hopeless', 'end it', 'no point'];
    const isEmergency = emergencyKeywords.some(kw => lowerContent.includes(kw));

    return {
      primaryEmotion,
      stressSeverity,
      burnoutRisk,
      confidenceScore,
      summary: isEmergency 
        ? "This entry indicates severe emotional distress. Immediate support is recommended."
        : `You expressed feelings of ${primaryEmotion.toLowerCase()} related to your academic journey.`,
      feedback: isEmergency 
        ? "Your feelings are valid. Please reach out to someone you trust or a helpline immediately."
        : "It's completely normal to feel overwhelmed during intense preparation periods. You're not alone.",
      suggestions: isEmergency 
        ? ["Contact a helpline right away", "Talk to a family member or friend", "Consider professional counseling"]
        : [
            "Take a 10-minute walk outside to reset",
            "Break down your study goals into smaller achievable tasks",
            "Practice gratitude: list 3 things you're thankful for today",
            "Schedule a short mindfulness break"
          ],
      triggers: triggers.length > 0 ? triggers : ["Academic workload", "Future uncertainty"]
    };
  }

  static async generateWellnessPlan(moodData: any): Promise<any> {
    return {
      title: "Balanced Exam Prep Routine",
      focusAreas: ["Energy Restoration", "Mindful Studying", "Recovery"],
      dailyPlan: [
        "6:30 AM - Wake up & light stretching (10 mins)",
        "7:00 AM - Mindful breakfast + 5 min meditation",
        "Study in 50 min blocks with 10 min movement breaks",
        "Hydrate: 3L water target",
        "Evening wind-down: No screens after 9:30 PM",
        "Journal 3 things that went well today"
      ],
      customTips: moodData.burnoutRisk === 'high' 
        ? ["Prioritize sleep over extra study hours", "Incorporate yoga or breathing exercises"] 
        : ["Add 20 minutes of light exercise to boost endorphins"]
    };
  }

  static async predictBurnout(entries: MoodEntry[]): Promise<{risk: string; score: number; reasons: string[]}> {
    if (entries.length < 3) {
      return { risk: 'low', score: 65, reasons: ['Limited data available'] };
    }

    const recent = entries.slice(-5);
    const avgStress = recent.reduce((sum, e) => sum + e.stressLevel, 0) / recent.length;
    const avgSleep = recent.reduce((sum, e) => sum + e.sleepHours, 0) / recent.length;
    const lowEnergyCount = recent.filter(e => e.energyLevel < 5).length;

    let risk = 'low';
    let score = 75;
    const reasons: string[] = [];

    if (avgStress > 7) {
      risk = 'high';
      score = 32;
      reasons.push('Consistently high stress levels');
    }
    if (avgSleep < 6) {
      risk = risk === 'high' ? 'high' : 'medium';
      score = Math.max(20, score - 25);
      reasons.push('Insufficient sleep on average');
    }
    if (lowEnergyCount > 2) {
      risk = 'high';
      score = Math.max(15, score - 30);
      reasons.push('Persistent low energy');
    }

    return {
      risk: risk as any,
      score: Math.floor(Math.max(10, Math.min(95, score))),
      reasons: reasons.length > 0 ? reasons : ['Stable patterns detected']
    };
  }

  static generateInsight(entries: MoodEntry[]): string {
    if (entries.length === 0) return "Start logging your moods to unlock personalized insights.";
    
    const avgStress = entries.reduce((a, b) => a + b.stressLevel, 0) / entries.length;
    
    if (avgStress > 7) {
      return "Your stress peaks on days with more than 8 hours of study. Try implementing the Pomodoro technique with longer breaks.";
    } else if (entries.filter(e => e.sleepHours < 6).length > entries.length / 2) {
      return "Data shows your mood is 42% better on days you sleep 7+ hours. Protect your sleep schedule.";
    }
    
    return "You've shown remarkable resilience. Your energy levels are highest after days with balanced study and rest.";
  }
}
