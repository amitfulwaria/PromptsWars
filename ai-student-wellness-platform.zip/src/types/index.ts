export interface MoodEntry {
  id: string;
  timestamp: string;
  mood: 'happy' | 'calm' | 'neutral' | 'anxious' | 'sad' | 'burned-out';
  stressLevel: number;
  energyLevel: number;
  sleepHours: number;
  studyHours: number;
  note?: string;
}

export interface JournalEntry {
  id: string;
  timestamp: string;
  content: string;
  analysis: {
    primaryEmotion: string;
    stressSeverity: number;
    burnoutRisk: 'low' | 'medium' | 'high';
    confidenceScore: number;
    summary: string;
    feedback: string;
    suggestions: string[];
    triggers?: string[];
  };
}

export interface WellnessPlan {
  id: string;
  title: string;
  description: string;
  tasks: Array<{
    title: string;
    duration?: string;
    completed: boolean;
  }>;
  generatedFor: string;
}

export interface Insight {
  id: string;
  date: string;
  title: string;
  content: string;
  type: 'mood' | 'sleep' | 'productivity' | 'burnout';
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
  progress?: number;
  maxProgress?: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export type Tab = 'dashboard' | 'checkin' | 'journal' | 'coach' | 'analytics' | 'plans' | 'achievements';
